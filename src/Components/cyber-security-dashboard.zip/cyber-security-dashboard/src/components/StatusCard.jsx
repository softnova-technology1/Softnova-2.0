import React from 'react';
import { FiGlobe, FiShield, FiMonitor } from 'react-icons/fi';
import styles from './StatusCard.module.css';

const StatusCard = ({ title, status, description, icon, isHealthy = true, isLoading = false }) => {
    const getIcon = () => {
        switch (icon) {
            case 'network':
                return <FiGlobe />;
            case 'firewall':
                return <FiShield />;
            case 'endpoint':
                return <FiMonitor />;
            default:
                return <FiShield />;
        }
    };

    const getVariant = () => {
        return isHealthy ? 'healthy' : 'critical';
    };

    if (isLoading) {
        return <div className={`${styles.statusCard} ${styles.skeleton} skeleton`}></div>;
    }

    return (
        <div className={`${styles.statusCard} ${styles[getVariant()]}`}>
            <div className={`${styles.iconContainer} ${styles[getVariant()]}`}>
                <div className={`${styles.pulse} ${styles[getVariant()]}`}></div>
                {getIcon()}
            </div>
            <div className={`${styles.status} ${styles[getVariant()]}`}>
                {status}
            </div>
            <div className={styles.title}>{title}</div>
            <div className={styles.description}>{description}</div>
        </div>
    );
};

export default StatusCard;
