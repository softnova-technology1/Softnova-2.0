import React, { useState } from 'react';
import {
    FiGrid,
    FiActivity,
    FiShield,
    FiAlertTriangle,
    FiFileText,
    FiBarChart2,
    FiUsers,
    FiLock,
    FiSettings,
    FiCommand
} from 'react-icons/fi';
import styles from './Sidebar.module.css';

const Sidebar = () => {
    const [activeItem, setActiveItem] = useState('Dashboard');

    const navItems = [
        { name: 'Dashboard', icon: <FiGrid /> },
        { name: 'Monitoring', icon: <FiActivity /> },
        { name: 'Threat Detection', icon: <FiShield /> },
        { name: 'Alerts', icon: <FiAlertTriangle /> },
        { name: 'Incidents', icon: <FiFileText /> },
        { name: 'Reports', icon: <FiBarChart2 /> },
        { name: 'Analytics', icon: <FiBarChart2 /> },
        { name: 'Users', icon: <FiUsers /> },
        { name: 'Access Control', icon: <FiLock /> },
        { name: 'Settings', icon: <FiSettings /> },
        { name: 'Admin Panel', icon: <FiCommand /> }
    ];

    return (
        <aside className={styles.sidebar}>
            <div className={styles.logo}>
                <div className={styles.logoIcon}>
                    <FiShield />
                </div>
                <span className={styles.logoText}>CyberGuard</span>
            </div>

            <nav className={styles.nav}>
                {navItems.map((item) => (
                    <div
                        key={item.name}
                        className={`${styles.navItem} ${activeItem === item.name ? styles.active : ''}`}
                        onClick={() => setActiveItem(item.name)}
                    >
                        <span className={styles.navIcon}>{item.icon}</span>
                        <span className={styles.navLabel}>{item.name}</span>
                    </div>
                ))}
            </nav>

            <div className={styles.userSection}>
                <div className={styles.userAvatar}>SC</div>
                <div className={styles.userInfo}>
                    <div className={styles.userName}>Sarah Connor</div>
                    <div className={styles.userRole}>Security Admin</div>
                </div>
            </div>
        </aside>
    );
};

export default Sidebar;
