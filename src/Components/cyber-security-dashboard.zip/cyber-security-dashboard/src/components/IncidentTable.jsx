import React, { useState, useMemo } from 'react';
import { FiExternalLink, FiChevronsUp, FiChevronsDown } from 'react-icons/fi';
import styles from './IncidentTable.module.css';

const IncidentTable = ({ incidents, searchValue, isLoading = false }) => {
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });

    const filteredIncidents = useMemo(() => {
        if (!searchValue) return incidents;

        return incidents.filter(incident =>
            incident.id.toLowerCase().includes(searchValue.toLowerCase()) ||
            incident.description.toLowerCase().includes(searchValue.toLowerCase()) ||
            incident.status.toLowerCase().includes(searchValue.toLowerCase()) ||
            incident.severity.toLowerCase().includes(searchValue.toLowerCase())
        );
    }, [incidents, searchValue]);

    const sortedIncidents = useMemo(() => {
        if (!sortConfig.key) return filteredIncidents;

        return [...filteredIncidents].sort((a, b) => {
            const aValue = a[sortConfig.key];
            const bValue = b[sortConfig.key];

            if (aValue < bValue) {
                return sortConfig.direction === 'asc' ? -1 : 1;
            }
            if (aValue > bValue) {
                return sortConfig.direction === 'asc' ? 1 : -1;
            }
            return 0;
        });
    }, [filteredIncidents, sortConfig]);

    const handleSort = (key) => {
        setSortConfig(prevConfig => ({
            key,
            direction: prevConfig.key === key && prevConfig.direction === 'asc' ? 'desc' : 'asc'
        }));
    };

    const getSortIcon = (columnKey) => {
        if (sortConfig.key !== columnKey) return null;
        return sortConfig.direction === 'asc' ? <FiChevronsUp className={styles.sortIcon} /> : <FiChevronsDown className={styles.sortIcon} />;
    };

    if (isLoading) {
        return <div className={`${styles.container} ${styles.skeleton} skeleton`}></div>;
    }

    return (
        <div className={styles.container}>
            <div className={styles.headerSection}>
                <h2 className={styles.title}>Recent Incidents</h2>
                <div className={styles.viewAll}>
                    <span>View All</span>
                    <FiExternalLink />
                </div>
            </div>

            <div className={styles.tableWrapper}>
                {sortedIncidents.length === 0 ? (
                    <div className={styles.noResults}>
                        No incidents found matching "{searchValue}"
                    </div>
                ) : (
                    <table className={styles.table}>
                        <thead>
                            <tr>
                                <th onClick={() => handleSort('id')}>
                                    Incident ID {getSortIcon('id')}
                                </th>
                                <th onClick={() => handleSort('description')}>
                                    Description {getSortIcon('description')}
                                </th>
                                <th onClick={() => handleSort('status')}>
                                    Status {getSortIcon('status')}
                                </th>
                                <th onClick={() => handleSort('severity')}>
                                    Severity {getSortIcon('severity')}
                                </th>
                                <th onClick={() => handleSort('time')}>
                                    Time {getSortIcon('time')}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedIncidents.map((incident) => (
                                <tr key={incident.id}>
                                    <td className={styles.incidentId}>{incident.id}</td>
                                    <td>{incident.description}</td>
                                    <td>
                                        <span className={`${styles.statusBadge} ${styles[incident.status.toLowerCase()]}`}>
                                            {incident.status}
                                        </span>
                                    </td>
                                    <td>
                                        <span className={`${styles.severityBadge} ${styles[incident.severity.toLowerCase()]}`}>
                                            {incident.severity}
                                        </span>
                                    </td>
                                    <td>{incident.time}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

export default IncidentTable;
