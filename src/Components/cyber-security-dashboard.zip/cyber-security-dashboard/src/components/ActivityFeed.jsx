import React from 'react';
import { FiClock, FiMapPin } from 'react-icons/fi';
import styles from './ActivityFeed.module.css';

const ActivityFeed = ({ activities, isLoading = false }) => {
    if (isLoading) {
        return <div className={`${styles.container} ${styles.skeleton} skeleton`}></div>;
    }

    return (
        <div className={styles.container}>
            <div className={styles.header}>
                <div>
                    <h3 className={styles.title}>Recent User Activities</h3>
                    <p className={styles.subtitle}>Monitor unusual user login patterns and access attempts</p>
                </div>
            </div>

            <div className={styles.feedList}>
                {activities.map((activity) => (
                    <div key={activity.id} className={styles.activityItem}>
                        <div className={styles.avatar}>{activity.avatar}</div>
                        <div className={styles.content}>
                            <div className={styles.userName}>{activity.user}</div>
                            <div className={styles.action}>{activity.action}</div>
                            <div className={styles.metadata}>
                                <div className={styles.time}>
                                    <FiClock size={12} />
                                    <span>{activity.time}</span>
                                </div>
                                <div className={styles.ip}>
                                    <FiMapPin size={12} />
                                    <span>{activity.ip}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ActivityFeed;
