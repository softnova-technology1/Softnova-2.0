import React from 'react';
import { FiSearch, FiBell, FiMail, FiSun, FiMoon } from 'react-icons/fi';
import styles from './Header.module.css';

const Header = ({ theme, onThemeToggle, onSearchChange, searchValue }) => {
    return (
        <header className={styles.header}>
            <div className={styles.searchContainer}>
                <FiSearch className={styles.searchIcon} />
                <input
                    type="text"
                    placeholder="Search incidents, threats, users..."
                    className={styles.searchInput}
                    value={searchValue}
                    onChange={(e) => onSearchChange(e.target.value)}
                />
            </div>

            <div className={styles.actions}>
                <button
                    className={styles.themeToggle}
                    onClick={onThemeToggle}
                    aria-label="Toggle theme"
                >
                    {theme === 'dark' ? <FiSun /> : <FiMoon />}
                </button>

                <button className={styles.iconButton} aria-label="Messages">
                    <FiMail />
                    <span className={styles.badge}>3</span>
                </button>

                <button className={styles.iconButton} aria-label="Notifications">
                    <FiBell />
                    <span className={styles.badge}>7</span>
                </button>

                <div className={styles.avatar}>SC</div>
            </div>
        </header>
    );
};

export default Header;
