import React from 'react';
import { useAnimatedCounter } from '../hooks/useAnimatedCounter';
import styles from './StatCard.module.css';

const StatCard = ({ icon, title, value, description, variant = 'info', isLoading = false }) => {
    const animatedValue = useAnimatedCounter(
        typeof value === 'number' ? value : 0,
        2000
    );

    if (isLoading) {
        return <div className={`${styles.statCard} ${styles.skeleton} skeleton`}></div>;
    }

    return (
        <div className={`${styles.statCard} ${styles[variant]}`}>
            <div className={styles.header}>
                <div className={`${styles.iconWrapper} ${styles[variant]}`}>
                    {icon}
                </div>
            </div>
            <div className={styles.value}>
                {typeof value === 'number' ? animatedValue : value}
                {typeof value === 'number' && value !== animatedValue && '%'}
            </div>
            <div className={styles.title}>{title}</div>
            <div className={styles.description}>{description}</div>
        </div>
    );
};

export default StatCard;
