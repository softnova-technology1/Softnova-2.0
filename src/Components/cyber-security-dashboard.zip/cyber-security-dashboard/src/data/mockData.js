export const mockIncidents = [
    {
        id: 'INC-2025-001',
        description: 'Unauthorized access attempt on database server',
        status: 'Open',
        severity: 'Critical',
        time: '2 hours ago',
        assignee: 'John Doe',
        source: '192.168.1.45'
    },
    {
        id: 'INC-2025-002',
        description: 'Malware detected on endpoint workstation',
        status: 'Investigating',
        severity: 'High',
        time: '4 hours ago',
        assignee: 'Jane Smith',
        source: 'WS-2045'
    },
    {
        id: 'INC-2025-003',
        description: 'Phishing email campaign targeting employees',
        status: 'Resolved',
        severity: 'Medium',
        time: 'Yesterday',
        assignee: 'Bob Johnson',
        source: 'Email Gateway'
    },
    {
        id: 'INC-2025-004',
        description: 'DDoS attack initiated on public-facing website',
        status: 'Open',
        severity: 'Critical',
        time: '3 days ago',
        assignee: 'Sarah Connor',
        source: 'External'
    },
    {
        id: 'INC-2025-005',
        description: 'Suspicious outbound connection from internal server',
        status: 'Investigating',
        severity: 'High',
        time: '5 days ago',
        assignee: 'Mike Ross',
        source: '10.0.5.23'
    }
];

export const mockStats = {
    threatLevel: 'Critical',
    activeThreats: 28,
    compromisedEndpoints: 5,
    securityScore: 88
};

export const mockStatusCards = [
    {
        id: 1,
        title: 'Network Status',
        status: 'Online',
        description: 'All network segments fully operational.',
        icon: 'network',
        isHealthy: true
    },
    {
        id: 2,
        title: 'Firewall Health',
        status: 'Optimal',
        description: 'Firewall rules are actively enforced and updated.',
        icon: 'firewall',
        isHealthy: true
    },
    {
        id: 3,
        title: 'Endpoint Protection',
        status: 'Active',
        description: 'Antivirus and EDR solutions are running.',
        icon: 'endpoint',
        isHealthy: true
    }
];

export const mockThreatVolumeData = [
    { month: 'Jan', cyberAttacks: 185, malwareDetected: 92 },
    { month: 'Feb', cyberAttacks: 220, malwareDetected: 115 },
    { month: 'Mar', cyberAttacks: 195, malwareDetected: 98 },
    { month: 'Apr', cyberAttacks: 245, malwareDetected: 128 },
    { month: 'May', cyberAttacks: 280, malwareDetected: 145 },
    { month: 'Jun', cyberAttacks: 310, malwareDetected: 162 }
];

export const mockAnomalyScoreData = [
    { time: '00h', score: 22 },
    { time: '04h', score: 18 },
    { time: '08h', score: 35 },
    { time: '12h', score: 28 },
    { time: '16h', score: 42 },
    { time: '20h', score: 31 }
];

export const mockFailedLoginsData = [
    { time: '00h', attempts: 12 },
    { time: '04h', attempts: 8 },
    { time: '08h', attempts: 15 },
    { time: '12h', attempts: 22 },
    { time: '16h', attempts: 28 },
    { time: '20h', attempts: 35 }
];

export const mockUserActivities = [
    {
        id: 1,
        user: 'John Doe',
        action: 'logged in from new device',
        ip: '203.0.113.45',
        time: '2 mins ago',
        avatar: 'JD'
    },
    {
        id: 2,
        user: 'Alice Smith',
        action: 'accessed sensitive client data from unapproved location',
        ip: '198.51.100.23',
        time: '15 mins ago',
        avatar: 'AS'
    },
    {
        id: 3,
        user: 'Bob Johnson',
        action: 'modified firewall rules on production server',
        ip: '192.0.2.67',
        time: '1 hour ago',
        avatar: 'BJ'
    },
    {
        id: 4,
        user: 'Charlie Brown',
        action: 'failed login attempt (5 times) on administrative portal',
        ip: '203.0.113.89',
        time: '3 hours ago',
        avatar: 'CB'
    }
];
