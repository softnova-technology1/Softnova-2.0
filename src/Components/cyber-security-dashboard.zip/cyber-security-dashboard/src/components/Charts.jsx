import React from 'react';
import {
    BarChart,
    Bar,
    LineChart,
    Line,
    AreaChart,
    Area,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer
} from 'recharts';
import styles from './Charts.module.css';

const Charts = ({
    threatVolumeData,
    anomalyScoreData,
    failedLoginsData,
    theme,
    isLoading = false
}) => {
    const isDark = theme === 'dark';

    const chartColors = {
        primary: '#3b82f6',
        secondary: '#8b5cf6',
        danger: '#ef4444',
        grid: isDark ? '#2d3961' : '#e2e8f0',
        text: isDark ? '#94a3b8' : '#64748b'
    };

    if (isLoading) {
        return (
            <>
                <div className={`${styles.container} ${styles.skeleton} skeleton`}></div>
                <div className={`${styles.container} ${styles.skeleton} skeleton`}></div>
                <div className={`${styles.container} ${styles.skeleton} skeleton`}></div>
            </>
        );
    }

    return (
        <>
            {/* Bar Chart - Threat Volume */}
            <div className={styles.container}>
                <div className={styles.header}>
                    <div className={styles.titleSection}>
                        <h3 className={styles.title}>Threat Volume Trend</h3>
                        <p className={styles.subtitle}>Monthly overview of detected cyber attacks and malware instances</p>
                    </div>
                </div>
                <div className={styles.content}>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={threatVolumeData}>
                            <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                            <XAxis
                                dataKey="month"
                                stroke={chartColors.text}
                                style={{ fontSize: '0.85rem' }}
                            />
                            <YAxis
                                stroke={chartColors.text}
                                style={{ fontSize: '0.85rem' }}
                            />
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: isDark ? '#1a2341' : '#ffffff',
                                    border: `1px solid ${chartColors.grid}`,
                                    borderRadius: '8px',
                                    color: chartColors.text
                                }}
                            />
                            <Legend
                                wrapperStyle={{ fontSize: '0.9rem' }}
                            />
                            <Bar
                                dataKey="cyberAttacks"
                                fill={chartColors.primary}
                                radius={[8, 8, 0, 0]}
                                name="Cyber Attacks"
                            />
                            <Bar
                                dataKey="malwareDetected"
                                fill={chartColors.danger}
                                radius={[8, 8, 0, 0]}
                                name="Malware Detected"
                            />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Line Chart - Anomaly Score */}
            <div className={styles.container}>
                <div className={styles.header}>
                    <div className={styles.titleSection}>
                        <h3 className={styles.title}>Network Anomaly Score</h3>
                        <p className={styles.subtitle}>Real-time detection of unusual network behavior</p>
                    </div>
                </div>
                <div className={styles.content}>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={anomalyScoreData}>
                            <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                            <XAxis
                                dataKey="time"
                                stroke={chartColors.text}
                                style={{ fontSize: '0.85rem' }}
                            />
                            <YAxis
                                stroke={chartColors.text}
                                style={{ fontSize: '0.85rem' }}
                            />
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: isDark ? '#1a2341' : '#ffffff',
                                    border: `1px solid ${chartColors.grid}`,
                                    borderRadius: '8px',
                                    color: chartColors.text
                                }}
                            />
                            <Legend
                                wrapperStyle={{ fontSize: '0.9rem' }}
                            />
                            <Line
                                type="monotone"
                                dataKey="score"
                                stroke={chartColors.secondary}
                                strokeWidth={3}
                                dot={{ fill: chartColors.secondary, r: 5 }}
                                activeDot={{ r: 7 }}
                                name="Anomaly Score"
                            />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Area Chart - Failed Logins */}
            <div className={styles.container}>
                <div className={styles.header}>
                    <div className={styles.titleSection}>
                        <h3 className={styles.title}>Failed Login Attempts</h3>
                        <p className={styles.subtitle}>Hourly count of unsuccessful login attempts across services</p>
                    </div>
                </div>
                <div className={styles.content}>
                    <ResponsiveContainer width="100%" height={300}>
                        <AreaChart data={failedLoginsData}>
                            <defs>
                                <linearGradient id="colorAttempts" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={chartColors.danger} stopOpacity={0.3} />
                                    <stop offset="95%" stopColor={chartColors.danger} stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                            <XAxis
                                dataKey="time"
                                stroke={chartColors.text}
                                style={{ fontSize: '0.85rem' }}
                            />
                            <YAxis
                                stroke={chartColors.text}
                                style={{ fontSize: '0.85rem' }}
                            />
                            <Tooltip
                                contentStyle={{
                                    backgroundColor: isDark ? '#1a2341' : '#ffffff',
                                    border: `1px solid ${chartColors.grid}`,
                                    borderRadius: '8px',
                                    color: chartColors.text
                                }}
                            />
                            <Legend
                                wrapperStyle={{ fontSize: '0.9rem' }}
                            />
                            <Area
                                type="monotone"
                                dataKey="attempts"
                                stroke={chartColors.danger}
                                strokeWidth={2}
                                fillOpacity={1}
                                fill="url(#colorAttempts)"
                                name="Failed Attempts"
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </>
    );
};

export default Charts;
