import React, { useState, useEffect } from 'react';
import { FiAlertTriangle, FiActivity, FiMonitor, FiAward } from 'react-icons/fi';
import StatCard from '../components/StatCard';
import IncidentTable from '../components/IncidentTable';
import StatusCard from '../components/StatusCard';
import Charts from '../components/Charts';
import ActivityFeed from '../components/ActivityFeed';
import {
    mockIncidents,
    mockStats,
    mockStatusCards,
    mockThreatVolumeData,
    mockAnomalyScoreData,
    mockFailedLoginsData,
    mockUserActivities
} from '../data/mockData';
import styles from './Dashboard.module.css';

const Dashboard = ({ theme, searchValue }) => {
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        // Simulate data loading
        const timer = setTimeout(() => {
            setIsLoading(false);
        }, 1500);

        return () => clearTimeout(timer);
    }, []);

    return (
        <div className={styles.dashboard}>
            {/* Stats Cards */}
            <div className={styles.statsGrid}>
                <StatCard
                    icon={<FiAlertTriangle />}
                    title="Critical Threat Level"
                    value={mockStats.threatLevel}
                    description="Overall threat level indicating potential security risks"
                    variant="critical"
                    isLoading={isLoading}
                />
                <StatCard
                    icon={<FiActivity />}
                    title="Active Threats"
                    value={mockStats.activeThreats}
                    description="Currently active and unresolved security vulnerabilities"
                    variant="warning"
                    isLoading={isLoading}
                />
                <StatCard
                    icon={<FiMonitor />}
                    title="Compromised Endpoints"
                    value={mockStats.compromisedEndpoints}
                    description="Total number of devices showing signs of breach or compromise"
                    variant="warning"
                    isLoading={isLoading}
                />
                <StatCard
                    icon={<FiAward />}
                    title="Security Score"
                    value={mockStats.securityScore}
                    description="Overall security posture based on system metrics"
                    variant="info"
                    isLoading={isLoading}
                />
            </div>

            {/* Incidents Table */}
            <IncidentTable
                incidents={mockIncidents}
                searchValue={searchValue}
                isLoading={isLoading}
            />

            {/* Status Cards */}
            <div className={styles.statusGrid}>
                {mockStatusCards.map((card) => (
                    <StatusCard
                        key={card.id}
                        title={card.title}
                        status={card.status}
                        description={card.description}
                        icon={card.icon}
                        isHealthy={card.isHealthy}
                        isLoading={isLoading}
                    />
                ))}
            </div>

            {/* Charts */}
            <div className={styles.chartsSection}>
                <Charts
                    threatVolumeData={mockThreatVolumeData}
                    anomalyScoreData={mockAnomalyScoreData}
                    failedLoginsData={mockFailedLoginsData}
                    theme={theme}
                    isLoading={isLoading}
                />
            </div>

            {/* Activity Feed */}
            <ActivityFeed
                activities={mockUserActivities}
                isLoading={isLoading}
            />
        </div>
    );
};

export default Dashboard;
